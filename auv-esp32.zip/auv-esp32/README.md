# AUV with ESP32

ESP32-based autonomous underwater vehicle with camera, obstacle avoidance, and a web dashboard.