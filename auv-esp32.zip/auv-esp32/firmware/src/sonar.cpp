#include "sonar.h"

void initSonar() {
  // Initialize ultrasonic sensor pins
}

float readSonar() {
  // Return measured distance
  return 0.0;
}
