#include "wifi_server.h"

void connectWiFi() {
  // Connect to Wi-Fi network
}

void startWebServer() {
  // Start web server or prepare for HTTP communication
}

void sendDataToDashboard(float distance) {
  // Send data to web dashboard
}
