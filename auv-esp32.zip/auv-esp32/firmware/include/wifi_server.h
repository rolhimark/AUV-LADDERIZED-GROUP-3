void connectWiFi();
void startWebServer();
void sendDataToDashboard(float distance);