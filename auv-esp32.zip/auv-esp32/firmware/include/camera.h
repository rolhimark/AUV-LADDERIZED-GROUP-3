void initCamera();
void captureAndDetectObjects();