void initSonar();
float readSonar();