void initMotors();
void moveForward();
void stopMotors();